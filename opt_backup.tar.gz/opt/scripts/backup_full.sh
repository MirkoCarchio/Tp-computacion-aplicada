#!/bin/bash

# Script de backup completo (backup_full.sh)
# Ubicación: /opt/scripts/backup_full.sh
# Requisitos:
# - Aceptar argumentos de origen y destino.
# - Nombres de backup con fecha ANSI (YYYYMMDD).
# - Almacenar en /backup_dir.
# - Opción de ayuda (-help).
# - Validar disponibilidad de origen y destino.

# Formato de fecha ANSI (YYYYMMDD)
FECHA_ACTUAL=$(date +%Y%m%d)

# Directorio de backups por defecto si no se especifica en el script (aunque el TP pide por argumento)
# BACKUP_BASE_DIR="/backup_dir"

# --- Función de Ayuda ---
mostrar_ayuda() {
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo ""
    echo "Este script realiza un backup completo de un directorio de origen a un directorio de destino."
    echo ""
    echo "Argumentos:"
    echo "  <directorio_origen>  : Ruta absoluta del directorio a backupear."
    echo "  <directorio_destino> : Ruta absoluta del directorio donde se guardará el backup."
    echo ""
    echo "Opciones:"
    echo "  -help                : Muestra esta ayuda y sale."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  Esto creará un archivo de backup como /backup_dir/log_bkp_YYYYMMDD.tar.gz"
    echo ""
    echo "  $0 /www_dir /backup_dir"
    echo "  Esto creará un archivo de backup como /backup_dir/www_dir_bkp_YYYYMMDD.tar.gz"
}

# --- Procesar argumentos ---
if [ "$1" == "-help" ]; then
    mostrar_ayuda
    exit 0
fi

# Validar número de argumentos
if [ "$#" -ne 2 ]; then
    echo "Error: Número incorrecto de argumentos."
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# --- Validación de origen y destino ---
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no es un directorio válido."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no es un directorio válido."
    exit 1
fi

# Extraer el nombre base del directorio de origen para el nombre del archivo de backup
NOMBRE_BASE=$(basename "$ORIGEN")
NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA_ACTUAL}.tar.gz"
RUTA_COMPLETA_DESTINO="${DESTINO}/${NOMBRE_ARCHIVO}"

echo "Iniciando backup de '$ORIGEN' a '$RUTA_COMPLETA_DESTINO'..."

# --- Realizar el backup con tar y gzip ---
# La opción -P asegura que se guarden las rutas completas desde la raíz si ORIGEN es /var/log, por ejemplo.
# -z para gzip, -c para crear, -v para verbose (mostrar progreso), -f para archivo.
tar -zcvf "$RUTA_COMPLETA_DESTINO" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup de '$ORIGEN' completado exitosamente en '$RUTA_COMPLETA_DESTINO'."
else
    echo "Error: El backup de '$ORIGEN' falló."
    exit 1
fi

exit 0
